<template>
  <b-container class="home">
    <h1 v-if="!fetchFinish">Loading</h1>

    <label for="rows">Number of rows</label>
    <input type="text" name="rows" v-model="pageSize" />
    <button class="btn btn-info mx-auto" @click>Change table rows</button>
    <!-- <ul>
      <li v-for="(user, index) in users" :key="index">Name: {{ user.name }}</li>
    </ul>-->
    <!-- <b-table striped hover :items="items"></b-table> -->

    <b-container class="bg-gray">
      <table>
        <thead>
          <tr>
            <th @click="sort('userId')">User Id</th>
            <th @click="sort('id')">id</th>
            <th @click="sort('title')">Title</th>
            <th @click="sort('body')">Body</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in sortedItems" :key="item.id">
            <td>{{item.userId}}</td>
            <td>{{item.id}}</td>
            <td>{{item.title}}</td>
            <td>{{item.body}}</td>
          </tr>
        </tbody>
      </table>
      <p>
        <button class="btn btn-light" @click="prevPage">Previous</button>
        <button class="btn btn-light" @click="nextPage">Next</button>
      </p>
      debug: sort={{currentSort}}, dir={{currentSortDir}}
    </b-container>
  </b-container>
</template>

<script>
// @ is an alias to /src
// import HelloWorld from "@/components/HelloWorld.vue";
import axios from "axios";
export default {
  name: "home",
  data() {
    return {
      items: [],
      currentSort: "id",
      currentSortDir: "asc",
      fetchFinish: false,
      pageSize: 500,
      currentPage: 1
    };
  },
  components: {},
  methods: {
    sort: function(s) {
      if (this.fetchFinish) {
        //if s == current sort, reverse
        if (s === this.currentSort) {
          this.currentSortDir = this.currentSortDir === "asc" ? "desc" : "asc";
        }
      }
      this.currentSort = s;
    },
    nextPage: function() {
      if (this.currentPage * this.pageSize < this.items.length)
        this.currentPage++;
    },
    prevPage: function() {
      if (this.currentPage > 1) this.currentPage--;
    }
  },
  computed: {
    sortedItems: function() {
      return this.items
        .sort((a, b) => {
          let modifier = 1;
          if (this.currentSortDir === "desc") modifier = -1;
          if (a[this.currentSort] < b[this.currentSort]) return -1 * modifier;
          if (a[this.currentSort] > b[this.currentSort]) return 1 * modifier;
          return 0;
        })
        .filter((row, index) => {
          let start = (this.currentPage - 1) * this.pageSize;
          let end = this.currentPage * this.pageSize;
          if (index >= start && index < end) return true;
        });
    }
  },
  mounted() {
    axios
      .get("https://jsonplaceholder.typicode.com/photos")
      .then(response => (this.items = response.data))
      .then(console.log(this.items))
      .then((this.fetchFinish = true));
  }
};
</script>

<style lang="scss" scoped>
.bg-gray {
  background-color: rgb(223, 223, 223);
}
</style>
