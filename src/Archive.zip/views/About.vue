<template>
  <div class="about">
    <b-container>
      <h1 class="my-5">API call table sorting and pagination</h1>
      <button class="btn btn-info" @click="logTheData">console log data</button>
      <h2>Api call parameters</h2>
      <table class="table table-striped table-hover">
        <thead class="thead-dark">
          <tr>
            <th>Requested page</th>
            <th>Total pages</th>
            <th>per_page</th>
            <th>total</th>
            <th>Last updated</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{{dataFromAPI_status_data.page}}</td>
            <td>{{dataFromAPI_status_data.pages}}</td>
            <td>{{dataFromAPI_status_data.per_page}}</td>
            <td>{{dataFromAPI_status_data.total}}</td>
            <td>{{dataFromAPI_status_data.lastupdated}}</td>
          </tr>
        </tbody>
      </table>

      <!-- Pagination -->
      <nav aria-label="Page navigation">
        <ul class="pagination">
          <li class="page-item">
            <a @click.prevent="prevPage" class="page-link" href="#">Previous</a>
          </li>
          <!-- <li class="page-item">
            <a class="page-link" href="#">1</a>
          </li>
          <li class="page-item">
            <a class="page-link" href="#">2</a>
          </li>
          <li class="page-item">
            <a class="page-link" href="#">3</a>
          </li>-->
          <li @click.prevent="nextPage" class="page-item">
            <a class="page-link" href="#">Next</a>
          </li>
        </ul>
      </nav>

      <button
        @click="showAllRows"
        class="btn btn-danger btn-sm float-right"
      >Show all pages ({{ dataFromAPI_status_data.total }})</button>

      <h2>Actual data from API</h2>
      <table class="table table-striped table-hover">
        <thead class="thead-dark">
          <tr>
            <!-- <th @click="sort('index')">Index</th> -->
            <th @click="sort('country.value')">Country</th>
            <th @click="sort('date')">Data</th>
            <th @click="sort('value')">Population</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(rowOfData, index) in sortedItems" :key="index">
            <!-- <td>{{index}}</td> -->
            <td>{{rowOfData.country.value}}</td>
            <td>{{rowOfData.date}}</td>
            <td>{{rowOfData.value}}</td>
          </tr>
        </tbody>
      </table>
    </b-container>
    <!-- <h1>This is an about page</h1> -->
  </div>
</template>

<script>
// @ is an alias to /src
// import HelloWorld from "@/components/HelloWorld.vue";
import axios from "axios";
export default {
  name: "home",
  data() {
    return {
      dataFromAPI: [],
      dataFromAPI_rowsN: [],
      dataFromAPI_status_data: [],
      mira: [],
      currentSort: "country.value",
      currentSortDir: "asc",
      fetchFinish: false,
      pageSize: 25,
      currentPage: 1,
      nextPageNr: 2,
      prevPageNr: 2,
      totalPages: 222,
      apiCallAddress_base:
        "http://api.worldbank.org/v2/country/all/indicator/SP.POP.TOTL?date=1990:2010&format=json",
      apiCallAddress_newCall: ""
    };
  },
  components: {},
  methods: {
    logTheData() {
      console.log("mounted: ", this.dataFromAPI);
      console.log("dataFromAPI_status_data: ", this.dataFromAPI_status_data);
      this.getDataFromAPI_rows;
      this.getOnlyDataTableNeeds;
    },
    sort: function(s) {
      if (this.fetchFinish) {
        //if s == current sort, reverse
        if (s === this.currentSort) {
          this.currentSortDir = this.currentSortDir === "asc" ? "desc" : "asc";
        }
      }
      this.currentSort = s;
    },
    nextPage() {
      if (this.currentPage <= this.totalPages) {
        this.currentPage++;
        this.nextPageNr = this.currentPage;
        this.apiCallAddress_newCall =
          this.apiCallAddress_base + "&page=" + this.nextPageNr;
        this.getNewData(this.apiCallAddress_newCall);
        console.log(
          "this.apiCallAddress_newCall: ",
          this.apiCallAddress_newCall
        );
      } else {
        console.log("you are at the far end");
      }
    },
    prevPage() {
      if (this.currentPage > 1) {
        this.currentPage--;
        this.prevPageNr = this.currentPage;
        this.apiCallAddress_newCall =
          this.apiCallAddress_base + "&page=" + this.prevPageNr;
        this.getNewData(this.apiCallAddress_newCall);
        console.log(
          "this.apiCallAddress_newCall: ",
          this.apiCallAddress_newCall
        );
      } else {
        console.log("you are at the low end");
      }
    },
    showAllRows() {
      this.apiCallAddress_newCall =
        this.apiCallAddress_base +
        "&per_page=" +
        this.dataFromAPI_status_data.total;
      this.getNewData(this.apiCallAddress_newCall);
      console.log("this.apiCallAddress_newCall: ", this.apiCallAddress_newCall);
    },
    getNewData(url) {
      axios.get(url).then(response => (this.dataFromAPI = response.data));
    }
  },
  computed: {
    getOnlyDataTableNeeds() {
      // This is me trying to copy an array
      //let country, Year, Population;
      // let oneRow = [];
      // let mira = this.dataFromAPI[1];
      // for (let i = 0; i < mira.length; i++) {
      //   // oneRow[i] = mira[i]
      //   for (let v = 0; v < mira[i].length; v++) {
      //     oneRow[i][v].push(mira[i][v]);
      //     console.log("is it cycle? ");
      //     console.log("only:", oneRow);
      //   }
      // }
      // console.log("only:", oneRow);
    },
    getDataFromAPI_rows() {
      return (this.dataFromAPI_rowsN = this.dataFromAPI[1]);
    },
    sortedItems: function() {
      if (this.getDataFromAPI_rows != null) {
        return this.getDataFromAPI_rows.sort((a, b) => {
          let modifier = 1;
          if (this.currentSortDir === "desc") modifier = -1;
          if (a[this.currentSort] < b[this.currentSort]) return -1 * modifier;
          if (a[this.currentSort] > b[this.currentSort]) return 1 * modifier;
          return 0;
        });
      }
      return 0;
    }
  },
  watch: {
    dataFromAPI() {
      if (this.dataFromAPI != []) {
        this.getDataFromAPI_rows;
        this.fetchFinish = true;
        console.log("Watch");
      }
    }
  },
  created() {
    axios
      .get(this.apiCallAddress_base)
      .then(response => (this.dataFromAPI = response.data))
      .then(this.getDataFromAPI_rows);
  },
  mounted() {
    console.log("mounted: ", this.dataFromAPI);
  },
  updated() {
    this.dataFromAPI_status_data = this.dataFromAPI[0];
    console.log(
      "updated(dataFromAPI_status_data): ",
      this.dataFromAPI_status_data
    );
  }
};
</script>

<style lang="scss" scoped>
.bg-gray {
  background-color: rgb(223, 223, 223);
}
</style>